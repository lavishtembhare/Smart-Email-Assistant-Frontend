console.log('Smart Email Assistant script loaded');

const API_GENERATE_URL = 'https://smart-email-assistant-d54q.onrender.com/api/email/generate';
const API_COMPOSE_URL = 'https://smart-email-assistant-d54q.onrender.com/api/email/compose';

const CONTENT_SELECTORS = [
  '.a3s.aiL',
  '.gmail_quote',
  '.h7',
  '[role="presentation"]',
];

const TOOLBAR_SELECTORS = [
  '.btC',
  '.aDh',
  '[role="toolbar"]',
  '.gU.Up',
];

// Gmail always renders a subject field in a full "Compose" popup, but never
// in an inline reply box — so its presence is what tells the two apart.
const SUBJECT_SELECTOR = 'input[name="subjectbox"]';
const RECIPIENT_SELECTOR = 'input[name="to"], textarea[name="to"]';

function createAIButton(mode) {
  const button = document.createElement('div');
  button.className = 'T-I J-J5-Ji T-I-KE L3 SEA smart-email-assistant-button';
  button.style.marginRight = '8px';
  const label = mode === 'compose' ? 'AI Compose' : 'AI Reply';
  button.textContent = label;
  button.setAttribute('role', 'button');
  button.setAttribute('aria-label', label);
  button.setAttribute('tabindex', '0');
  return button;
}

// A full compose popup gets role="dialog" in Gmail; an inline reply box
// doesn't. Scoping lookups to this ancestor (falling back to the whole
// document) keeps things correct if more than one compose window is open.
function getDialogScope(element) {
  return element.closest('[role="dialog"]') || document;
}

function detectComposeMode(toolbar) {
  const scope = getDialogScope(toolbar);
  const subjectField = scope.querySelector(SUBJECT_SELECTOR);
  return subjectField ? 'compose' : 'reply';
}

function getEmailContent() {
  for (const selector of CONTENT_SELECTORS) {
    const content = document.querySelector(selector);
    if (content) {
      return content.innerText.trim();
    }
  }
  return '';
}

function findComposeToolbar() {
  for (const selector of TOOLBAR_SELECTORS) {
    const toolbar = document.querySelector(selector);
    if (toolbar) {
      return toolbar;
    }
  }
  return null;
}

async function handleGenerateClick(button) {
  // A <div> has no real "disabled" state, so guard re-entrancy manually.
  if (button.dataset.loading === 'true') return;

  const mode = button.dataset.mode || 'reply';
  const scope = getDialogScope(button);

  let requestUrl;
  let requestBody;

  if (mode === 'compose') {
    const subjectField = scope.querySelector(SUBJECT_SELECTOR);
    const recipientField = scope.querySelector(RECIPIENT_SELECTOR);
    const subject = subjectField ? subjectField.value.trim() : '';
    const recipientEmail = recipientField ? recipientField.value.trim() : '';

    if (!subject) {
      alert('Add a subject line first, then click AI Compose.');
      return;
    }

    requestUrl = API_COMPOSE_URL;
    requestBody = { recipientEmail, subject, tone: 'professional' };
  } else {
    const emailContent = getEmailContent();
    if (!emailContent) {
      alert('Could not find the email content to reply to.');
      return;
    }

    requestUrl = API_GENERATE_URL;
    requestBody = { emailContent, tone: 'professional' };
  }

  const originalLabel = button.textContent;
  button.dataset.loading = 'true';
  button.classList.add('smart-email-assistant-loading');
  button.textContent = 'Generating...';

  try {
    const response = await fetch(requestUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const message = await response.text();
      throw new Error(message || `Request failed (${response.status})`);
    }

    const generatedText = await response.text();
    const composeBox = scope.querySelector('[role="textbox"][g_editable="true"]');

    if (composeBox) {
      composeBox.focus();
      document.execCommand('insertText', false, generatedText);
    } else {
      console.error('Compose box not found. Unable to insert AI-generated text.');
      alert('Could not find the compose box to insert the text into.');
    }
  } catch (error) {
    console.error(error);
    alert('Error generating email: ' + error.message);
  } finally {
    button.dataset.loading = 'false';
    button.classList.remove('smart-email-assistant-loading');
    button.textContent = originalLabel;
  }
}

function injectButton() {
  const existingButton = document.querySelector('.smart-email-assistant-button');
  if (existingButton) existingButton.remove();

  const toolbar = findComposeToolbar();
  if (!toolbar) {
    console.log('Compose toolbar not found.');
    return;
  }

  const mode = detectComposeMode(toolbar);
  console.log(`Toolbar found (${mode} mode). Injecting Smart Email Assistant button...`);
  const button = createAIButton(mode);
  button.dataset.mode = mode;
  button.addEventListener('click', () => handleGenerateClick(button));
  toolbar.insertBefore(button, toolbar.firstChild);
}

const observer = new MutationObserver((mutationsList) => {
  for (const mutation of mutationsList) {
    const addedNodes = Array.from(mutation.addedNodes);
    const hasComposeElements = addedNodes.some(
      (node) =>
        node.nodeType === Node.ELEMENT_NODE &&
        (node.matches('.aDh, .btC, [role="dialog"]') ||
          node.querySelector('.aDh, .btC, [role="dialog"]'))
    );

    if (hasComposeElements) {
      console.log('Compose window detected. Injecting Smart Email Assistant...');
      setTimeout(injectButton, 1000);
      break;
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true });

// Also try once on load, in case a compose window is already open
// (e.g. an inline reply box) before any mutation fires.
setTimeout(injectButton, 1500);